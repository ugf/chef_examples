service node[:services][:name] do
  action :restart
end